package com.example.springsecurityapplication.enumm;

public enum Status {
    Принят, Оформлен, Ожидает, Получен, Отменен

//    GOT(0, "Принят"),
//    FORMED(1, "Оформлен"),
//    PENDING(2, "Ожидает"),
//    RECIEVED(3, "Получен"),
//    CANCELLED(4, "Отменен");
//
//
//    private Integer id;
//    private String name;
//
//    Status(Integer id, String name) {
//        this.id = id;
//        this.name = name;
//    }
//
//
//    @Override
//    public String toString() {
//        return name;
//    }
//
//    public String getName() {
//        return name;
//    }


    }
