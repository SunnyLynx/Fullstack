
create table person
(
    id       serial primary key,
    login    varchar(50),
    password varchar(255),
    role     varchar(255)
);

alter table person
    owner to postgres;

create table category
(
    id   serial primary key,
    name varchar(255)
);

alter table category
    owner to postgres;
