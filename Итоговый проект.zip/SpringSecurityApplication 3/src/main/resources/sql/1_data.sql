INSERT INTO public.person (id, login, password, role) VALUES ( 'admin', '$2a$10$lLOGxgB8b0HDrY3WOPA3huJvoYFiafsGMR0P6sBF9llA83aEG.M5K', 'ROLE_ADMIN');
INSERT INTO public.person (id, login, password, role) VALUES ( 'user', '$2a$10$P9SFsdB0mUybdLIUaBSHt.9beBivRq.Fl0L/6uXa4vUG1UWNfaeJ.', 'ROLE_USER');

INSERT INTO public.category (id, name) VALUES (1, 'other');